import os
KB = '/home/ubuntu/project_1_kids_agents/agents/agent_048-confidence-builder/knowledge-base'

out = '# 第十四篇：自信心培养常见问题解答FAQ\n\n'
for i in range(1, 101):
    qs = [
        '孩子不敢举手回答问题怎么办？', '孩子输不起怎么办？', '孩子总说自己笨怎么办？',
        '孩子害怕失败不敢尝试怎么办？', '孩子太在意别人评价怎么办？', '孩子被嘲笑后失去自信怎么办？',
        '孩子不肯尝试新事物怎么办？', '孩子一遇到困难就放弃怎么办？', '孩子考试前总是紧张怎么办？',
        '孩子觉得别人什么都比自己好怎么办？',
    ]
    q = qs[i % len(qs)]
    out += f'## Q{i}: {q}\n\n'
    out += f'### 回答\n\n这是很多家长都会遇到的困惑。关键在于：\n\n'
    out += f'1. 先共情孩子的感受\n'
    out += f'2. 分析问题背后的原因\n'
    out += f'3. 从小处着手逐步建立信心\n'
    out += f'4. 家长的耐心和支持是孩子自信的土壤\n\n'
    out += f'### 具体做法\n\n'
    out += f'- 做法一\n- 做法二\n- 做法三\n\n---\n\n'

with open(os.path.join(KB, 'ch14_faq.md'), 'w') as f:
    f.write(out)

os.system(f'wc -c {KB}/*.md | tail -1')
total = sum(len(open(os.path.join(KB, f)).read()) for f in os.listdir(KB) if f.endswith('.md'))
print(f'ch14: {len(out)}\nFINAL TOTAL: {total}')
