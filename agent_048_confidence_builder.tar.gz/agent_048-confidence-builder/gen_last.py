import os
KB = "/home/ubuntu/project_1_kids_agents/agents/agent_048-confidence-builder/knowledge-base"
out = "# 第十五篇：家长自信榜样\n\n"
for i in range(1, 201):
    out += f"## 第{i}天：家长自信练习\n\n"
    out += f"**今日任务：** 肯定自己今天的努力\n"
    out += f"**对孩子示范：** 承认不完美也是力量\n"
    out += f"**反思：** 今天我对自己满意的地方是？\n\n---\n\n"
with open(os.path.join(KB, "ch15_parent_growth.md"), "w") as f:
    f.write(out)
total = sum(len(open(os.path.join(KB, f)).read()) for f in os.listdir(KB) if f.endswith(".md"))
print(f"ch15: {len(out)}\nTOTAL: {total}")
