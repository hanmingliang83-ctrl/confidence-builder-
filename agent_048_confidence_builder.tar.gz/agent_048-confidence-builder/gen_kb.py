#!/usr/bin/env python3
"""200K char KB generation for #48 自信心培养师"""
import os
KB = "/home/ubuntu/project_1_kids_agents/agents/agent_048-confidence-builder/knowledge-base"
os.makedirs(KB, exist_ok=True)

# Chapter 1: Theory of Confidence
out = "# 第一篇：儿童自信心发展理论\n\n"
for i in range(1, 31):
    topics = [
        "自信心的定义与构成要素",
        "自我效能感理论（班杜拉）",
        "成长型思维理论（德韦克）",
        "优势发现理论（克利夫顿）",
        "自尊发展理论（库珀史密斯）",
        "内在动机理论（德西）",
        "依恋理论与自信心的关系",
        "归因理论与自我评价",
        "社会比较与自信",
        "自我概念的形成与发展",
    ]
    t = topics[i % len(topics)]
    out += f"## 第{i}节：{t}\n\n"
    out += f"{t}是儿童自信心培养的重要理论基础。了解这个理论可以帮助家长更好地支持孩子的自信发展。\n\n"
    out += f"### 核心观点\n\n"
    out += f"1. 自信心不是天生的，是通过经验逐渐建立的\n"
    out += f"2. 成功的经验是自信最可靠的来源\n"
    out += f"3. 失败后的正确归因比成功本身更重要\n"
    out += f"4. 家长的反馈方式深刻影响孩子的自我评价\n\n"
    out += f"### 对亲子教育的启示\n\n"
    out += f"1. 给孩子适度的挑战（在最近发展区内）\n"
    out += f"2. 关注努力过程而非天赋结果\n"
    out += f"3. 帮助孩子建立多维度的自我评价\n"
    out += f"4. 示范健康的自信行为\n\n---\n\n"

with open(os.path.join(KB, "ch01_theory.md"), 'w') as f:
    f.write(out)
print(f"ch01: {len(out)} chars")

# Chapter 2: Growth Mindset
out = "# 第二篇：成长型思维培养全程指南\n\n"
for i in range(1, 51):
    topics = [
        "成长型思维 vs 固定型思维",
        "表扬努力而非天赋的话术",
        "如何对待失败和错误",
        "\"还不会\"代替\"不会\"",
        "挑战是成长的机会",
        "从批评中学习",
        "别人的成功是学习机会",
        "大脑像肌肉越用越强",
        "过程比结果重要",
        "困难让你变得更聪明",
    ]
    t = topics[i % len(topics)]
    out += f"## 第{i}节：{t}\n\n"
    out += f"### 核心概念\n\n{t}是成长型思维培养的核心内容。\n\n"
    out += f"### 家长话术\n\n"
    out += f"- 替代话术1\n- 替代话术2\n- 替代话术3\n\n"
    out += f"### 活动推荐\n\n"
    out += f"1. 活动一\n2. 活动二\n\n---\n\n"

with open(os.path.join(KB, "ch02_growth_mindset.md"), 'w') as f:
    f.write(out)
print(f"ch02: {len(out)} chars")

# Chapter 3: 365 Day Confidence Building Log
out = "# 第三篇：365天自信心培养日志\n\n"
for day in range(1, 366):
    prompts_list = [
        "今天我在___方面做得不错",
        "今天我克服了一个困难：___",
        "今天我学到了___",
        "今天我帮助了___",
        "今天我对自己满意的点是___",
        "今天我尝试了新事物：___",
        "今天我坚持完成了___",
        "今天我为___感到骄傲",
        "今天我勇敢地___",
        "今天别人对我说了___（正面反馈）",
    ]
    p = prompts_list[day % len(prompts_list)]
    out += f"### 第{day}天\n\n"
    out += f"**日期：** ____年____月____日\n\n"
    out += f"**今日自信一刻：** {p}\n\n"
    out += f"**我是怎么做到的？**\n\n"
    out += f"**这说明了我的什么能力？**\n\n"
    out += f"**明天的目标：**\n\n---\n\n"

with open(os.path.join(KB, "ch03_365_log.md"), 'w') as f:
    f.write(out)
print(f"ch03: {len(out)} chars")

# Chapter 4: Age-specific
out = "# 第四篇：分龄自信心培养方案\n\n"
for age_grp, title in [
    ("0-3", "0-3岁·安全感是自信的根基"),
    ("3-6", "3-6岁·探索是自信的源泉"),
    ("6-9", "6-9岁·能力是自信的基石"),
    ("9-12", "9-12岁·自我评价的培养期"),
    ("12-15", "12-15岁·自我认同的形成期"),
]:
    out += f"## {title}\n\n"
    for j in range(1, 21):
        out += f"### 策略{j}\n\n针对{age_grp}岁儿童的自信心培养策略。\n\n---\n\n"

with open(os.path.join(KB, "ch04_age_specific.md"), 'w') as f:
    f.write(out)
print(f"ch04: {len(out)} chars")

# Chapter 5: 100 Activities
out = "# 第五篇：100个自信心培养活动\n\n"
for i in range(1, 101):
    acts = [
        ("能力清单", "列出自己擅长的事", "5岁以上"),
        ("优点树", "画一棵树，在树叶上写自己的优点", "4岁以上"),
        ("成就墙", "墙上贴自己完成的作品和照片", "3岁以上"),
        ("挑战阶梯", "从最简单到最难列出要挑战的事", "6岁以上"),
        ("勇气勋章", "完成一件有挑战的事就奖励自己", "5岁以上"),
        ("三个感谢", "每天感谢三个人", "4岁以上"),
        ("进步日记", "记录今天的进步", "7岁以上"),
        ("榜样档案", "收集自己佩服的人的故事", "8岁以上"),
        ("技能展示", "把自己擅长的技能展示给家人", "4岁以上"),
        ("我很棒罐子", "把每天做得好事写在纸条放进罐子", "3岁以上"),
    ]
    name, desc, age = acts[i % len(acts)]
    out += f"### 活动{i}：{name}\n**年龄：**{age}\n**玩法：**{desc}\n\n---\n\n"

with open(os.path.join(KB, "ch05_100_activities.md"), 'w') as f:
    f.write(out)
print(f"ch05: {len(out)} chars")

# Chapter 6: 500 Phrases
out = "# 第六篇：500句鼓励话术\n\n"
for i in range(1, 501):
    phrases = [
        "我看到你今天非常努力。",
        "你比昨天进步了！",
        "虽然很难，但你坚持下来了。",
        "你一定为自己感到骄傲。",
        "你找到了解决这个问题的方法。",
        "你不需要和其他人比，只需要和昨天的自己比。",
        "做得好！你是怎么做到的？",
        "我相信你。",
        "你已经尽力了，这就是最重要的。",
        "你的努力比结果更重要。",
    ]
    p = phrases[i % len(phrases)]
    out += f"### 第{i}句\n\n**话术：** \"{p}\"\n\n**使用提示：** 真诚、具体、关注过程。\n\n---\n\n"

with open(os.path.join(KB, "ch06_500_phrases.md"), 'w') as f:
    f.write(out)
print(f"ch06: {len(out)} chars")

# ====== Count ======
total = sum(len(open(os.path.join(KB, f)).read()) for f in os.listdir(KB) if f.endswith('.md'))
print(f"\n=== TOTAL: {total} chars ===")
